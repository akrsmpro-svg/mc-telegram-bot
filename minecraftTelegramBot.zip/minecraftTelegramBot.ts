import TelegramBot from "node-telegram-bot-api";
import mineflayer, { type Bot } from "mineflayer";
import minecraftProtocol from "minecraft-protocol";
import { eq, and } from "drizzle-orm";
import { db, minecraftServersTable, type MinecraftServer } from "@workspace/db";
import { logger } from "./logger";

const { ping } = minecraftProtocol;

/* ------------------------------------------------------------------ */
/* Minecraft keep-alive bot manager                                    */
/* ------------------------------------------------------------------ */

interface ActiveBot {
  bot?: Bot;
  manualStop: boolean;
  reconnectTimer?: NodeJS.Timeout;
  failureStreak: number;
}

const activeBots = new Map<number, ActiveBot>();

const BASE_RECONNECT_DELAY_MS = 20_000;
const MAX_RECONNECT_DELAY_MS = 5 * 60_000;

function nextReconnectDelay(failureStreak: number): number {
  const backoff = Math.min(
    BASE_RECONNECT_DELAY_MS * 2 ** Math.max(0, failureStreak - 1),
    MAX_RECONNECT_DELAY_MS,
  );
  const jitter = Math.floor(Math.random() * 3000);
  return backoff + jitter;
}

function isServerActive(serverId: number): boolean {
  return activeBots.has(serverId);
}

function handlePreConnectFailure(serverId: number, failureStreak: number): void {
  const streak = failureStreak + 1;

  void (async () => {
    const [current] = await db
      .select()
      .from(minecraftServersTable)
      .where(eq(minecraftServersTable.id, serverId));

    if (!current || !current.isRunning) return;

    await db
      .update(minecraftServersTable)
      .set({
        connectedSince: null,
        disconnectionCount: (current.disconnectionCount ?? 0) + 1,
        lastError: "server offline (pre-connect ping failed)",
      })
      .where(eq(minecraftServersTable.id, serverId));

    const active = activeBots.get(serverId);
    if (active?.manualStop) return;

    const delay = nextReconnectDelay(streak);
    const timer = setTimeout(() => connect(serverId, streak), delay);
    activeBots.set(serverId, {
      manualStop: false,
      reconnectTimer: timer,
      failureStreak: streak,
    });
  })();
}

async function startMinecraftBot(server: MinecraftServer): Promise<void> {
  const existing = activeBots.get(server.id);
  if (existing) {
    existing.manualStop = true;
    if (existing.reconnectTimer) clearTimeout(existing.reconnectTimer);
    try {
      existing.bot?.quit();
    } catch {
      // ignore
    }
    activeBots.delete(server.id);
  }

  await db
    .update(minecraftServersTable)
    .set({ isRunning: true, lastError: null })
    .where(eq(minecraftServersTable.id, server.id));

  connect(server.id, 0);
}

function connect(serverId: number, failureStreak: number): void {
  void (async () => {
    const [server] = await db
      .select()
      .from(minecraftServersTable)
      .where(eq(minecraftServersTable.id, serverId));

    if (!server || !server.isRunning) return;

    logger.info(
      { serverId, host: server.host, port: server.port, failureStreak },
      "Connecting Minecraft keep-alive bot",
    );

    let detectedVersion: string | undefined;
    try {
      const pingResult = await Promise.race([
        ping({ host: server.host, port: server.port }),
        new Promise<never>((_, reject) =>
          setTimeout(() => reject(new Error("ping timeout")), 8000),
        ),
      ]);
      const versionName =
        typeof pingResult.version === "string"
          ? pingResult.version
          : pingResult.version?.name;
      const candidateVersion = versionName?.split(" ").pop();
      detectedVersion =
        candidateVersion &&
        minecraftProtocol.supportedVersions.includes(candidateVersion)
          ? candidateVersion
          : undefined;
      logger.info(
        { serverId, candidateVersion, detectedVersion },
        "Pre-connect ping succeeded, proceeding like a real client",
      );
    } catch (err) {
      logger.warn(
        { serverId, err: err instanceof Error ? err.message : err },
        "Pre-connect ping failed, server likely offline; will retry",
      );
      handlePreConnectFailure(serverId, failureStreak);
      return;
    }

    await new Promise((resolve) =>
      setTimeout(resolve, 400 + Math.floor(Math.random() * 600)),
    );

    const bot = mineflayer.createBot({
      host: server.host,
      port: server.port,
      username: server.playerName,
      auth: "offline",
      hideErrors: false,
      checkTimeoutInterval: 90_000,
      version: detectedVersion,
    });

    const entry: ActiveBot = { bot, manualStop: false, failureStreak };
    activeBots.set(serverId, entry);

    bot.once("spawn", () => {
      void db
        .update(minecraftServersTable)
        .set({
          connectedSince: new Date(),
          connectionCount: (server.connectionCount ?? 0) + 1,
          lastError: null,
        })
        .where(eq(minecraftServersTable.id, serverId));
      const active = activeBots.get(serverId);
      if (active) active.failureStreak = 0;
      logger.info({ serverId }, "Minecraft bot connected");
    });

    const handleDisconnect = (reason: string, isFailure: boolean) => {
      const active = activeBots.get(serverId);
      activeBots.delete(serverId);
      const streak = isFailure ? (active?.failureStreak ?? 0) + 1 : 0;

      void (async () => {
        const [current] = await db
          .select()
          .from(minecraftServersTable)
          .where(eq(minecraftServersTable.id, serverId));

        if (!current) return;

        await db
          .update(minecraftServersTable)
          .set({
            connectedSince: null,
            disconnectionCount: (current.disconnectionCount ?? 0) + 1,
            lastError: reason,
          })
          .where(eq(minecraftServersTable.id, serverId));

        const shouldReconnect = !active?.manualStop && current.isRunning;
        if (shouldReconnect) {
          const delay = nextReconnectDelay(streak);
          const timer = setTimeout(() => connect(serverId, streak), delay);
          activeBots.set(serverId, {
            bot,
            manualStop: false,
            reconnectTimer: timer,
            failureStreak: streak,
          });
        }
      })();
    };

    bot.on("end", (reason) => {
      logger.warn({ serverId, reason }, "Minecraft bot ended");
      handleDisconnect(String(reason ?? "end"), true);
    });
    bot.on("kicked", (reason) => {
      logger.warn({ serverId, reason }, "Minecraft bot kicked");
      handleDisconnect(String(reason), true);
    });
    bot.on("error", (err) => {
      logger.warn(
        {
          serverId,
          err: err.message,
          stack: err.stack,
          code: (err as NodeJS.ErrnoException).code,
        },
        "Minecraft bot error",
      );
      handleDisconnect(err.message, true);
    });
  })();
}

async function stopMinecraftBot(serverId: number): Promise<void> {
  const active = activeBots.get(serverId);
  if (active) {
    active.manualStop = true;
    if (active.reconnectTimer) clearTimeout(active.reconnectTimer);
    try {
      active.bot?.quit();
    } catch {
      // ignore
    }
    activeBots.delete(serverId);
  }

  await db
    .update(minecraftServersTable)
    .set({ isRunning: false, connectedSince: null })
    .where(eq(minecraftServersTable.id, serverId));
}

interface ServerCheckResult {
  online: boolean;
  playersOnline?: number;
  playersMax?: number;
  motd?: string;
  version?: string;
  error?: string;
}

async function checkMinecraftServer(
  host: string,
  port: number,
): Promise<ServerCheckResult> {
  try {
    const result = await Promise.race([
      ping({ host, port }),
      new Promise<never>((_, reject) =>
        setTimeout(() => reject(new Error("timeout")), 8000),
      ),
    ]);

    if ("players" in result) {
      return {
        online: true,
        playersOnline: result.players.online,
        playersMax: result.players.max,
        motd:
          typeof result.description === "string"
            ? result.description
            : (result.description as { text?: string })?.text,
        version: result.version.name,
      };
    }

    return { online: true };
  } catch (err) {
    return {
      online: false,
      error: err instanceof Error ? err.message : "unknown error",
    };
  }
}

function resumeRunningServersOnBoot(): void {
  void (async () => {
    const servers = await db
      .select()
      .from(minecraftServersTable)
      .where(eq(minecraftServersTable.isRunning, true));

    for (const server of servers) {
      connect(server.id, 0);
    }
  })();
}

/* ------------------------------------------------------------------ */
/* Telegram bot UI                                                     */
/* ------------------------------------------------------------------ */

const COLORS: Record<string, string> = {
  blue: "🔵",
  red: "🔴",
  green: "🟢",
  purple: "🟣",
  yellow: "🟡",
};

type SessionStep =
  | "add_name"
  | "add_host"
  | "add_port"
  | "add_player"
  | "edit_name"
  | "edit_host"
  | "edit_port"
  | "edit_player";

interface Session {
  step: SessionStep;
  serverId?: number;
  data: Partial<{
    name: string;
    host: string;
    port: number;
    playerName: string;
  }>;
}

const sessions = new Map<number, Session>();

function cancelKeyboard() {
  return {
    inline_keyboard: [[{ text: "❌ إلغاء", callback_data: "cancel" }]],
  };
}

function formatDuration(since: Date | null): string {
  if (!since) return "غير متصل";
  const seconds = Math.floor((Date.now() - since.getTime()) / 1000);
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;
  return `${h}س ${m}د ${s}ث`;
}

async function getUserServers(
  telegramUserId: string,
): Promise<MinecraftServer[]> {
  return db
    .select()
    .from(minecraftServersTable)
    .where(eq(minecraftServersTable.telegramUserId, telegramUserId))
    .orderBy(minecraftServersTable.createdAt);
}

async function getServer(
  serverId: number,
  telegramUserId: string,
): Promise<MinecraftServer | undefined> {
  const [server] = await db
    .select()
    .from(minecraftServersTable)
    .where(
      and(
        eq(minecraftServersTable.id, serverId),
        eq(minecraftServersTable.telegramUserId, telegramUserId),
      ),
    );
  return server;
}

export function startTelegramBot(): TelegramBot {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token) {
    throw new Error(
      "TELEGRAM_BOT_TOKEN environment variable is required but was not provided.",
    );
  }

  const bot = new TelegramBot(token, { polling: true });

  resumeRunningServersOnBoot();

  bot.on("polling_error", (err) => {
    logger.error({ err: err.message }, "Telegram polling error");
  });

  async function sendMainMenu(chatId: number, telegramUserId: string) {
    const servers = await getUserServers(telegramUserId);

    const rows = servers.map((s) => [
      {
        text: `${COLORS[s.botColor] ?? "🔵"} ${s.name} ${s.isRunning ? "✅" : "⏸"}`,
        callback_data: `srv:${s.id}:menu`,
      },
    ]);

    rows.push([{ text: "➕ اضافة سيرفر جديد", callback_data: "add:start" }]);
    rows.push([
      { text: "🛠 حلول مشاكل", callback_data: "help" },
      { text: "📦 اصدارات البوت", callback_data: "about" },
    ]);

    const text =
      servers.length === 0
        ? "🤖 بوت السيرفرات 24/7\n\nما عندك سيرفرات بعد.\nاضغط على زر اضافة سيرفر جديد للبدء."
        : `🤖 بوت السيرفرات 24/7\n\nعدد سيرفراتك: ${servers.length}`;

    await bot.sendMessage(chatId, text, {
      reply_markup: { inline_keyboard: rows },
    });
  }

  async function sendServerMenu(
    chatId: number,
    server: MinecraftServer,
    messageId?: number,
  ) {
    const text = [
      `${COLORS[server.botColor] ?? "🔵"} ${server.name}`,
      `العنوان: ${server.host}:${server.port}`,
      `اسم اللاعب: ${server.playerName}`,
      `الحالة: ${server.isRunning ? "✅ يعمل" : "⏸ متوقف"}`,
      server.isRunning
        ? `مدة الاتصال: ${formatDuration(server.connectedSince)}`
        : "",
      `عدد الاتصالات: ${server.connectionCount}`,
      `عدد الانقطاعات: ${server.disconnectionCount}`,
    ]
      .filter(Boolean)
      .join("\n");

    const rows = [
      [
        server.isRunning
          ? { text: "⏹ ايقاف البوت", callback_data: `srv:${server.id}:stop` }
          : {
              text: "▶️ تشغيل البوت",
              callback_data: `srv:${server.id}:start`,
            },
      ],
      [
        { text: "ℹ️ معلومات السيرفر", callback_data: `srv:${server.id}:info` },
        { text: "🔍 فحص السيرفر", callback_data: `srv:${server.id}:check` },
      ],
      [
        { text: "✏️ تعديل البيانات", callback_data: `srv:${server.id}:edit` },
        { text: "🎨 لون البوت", callback_data: `srv:${server.id}:color` },
      ],
      [{ text: "🗑 حذف السيرفر", callback_data: `srv:${server.id}:delete` }],
      [{ text: "◀️ رجوع", callback_data: "back:main" }],
    ];

    if (messageId) {
      await bot.editMessageText(text, {
        chat_id: chatId,
        message_id: messageId,
        reply_markup: { inline_keyboard: rows },
      });
    } else {
      await bot.sendMessage(chatId, text, {
        reply_markup: { inline_keyboard: rows },
      });
    }
  }

  bot.onText(/\/start/, async (msg) => {
    const chatId = msg.chat.id;
    await sendMainMenu(chatId, String(chatId));
  });

  bot.on("callback_query", async (query) => {
    const chatId = query.message?.chat.id;
    const messageId = query.message?.message_id;
    const data = query.data;
    if (!chatId || !data) return;

    const telegramUserId = String(chatId);

    try {
      if (data === "cancel") {
        sessions.delete(chatId);
        await bot.answerCallbackQuery(query.id, { text: "تم الإلغاء" });
        await sendMainMenu(chatId, telegramUserId);
        return;
      }

      if (data === "back:main") {
        await bot.answerCallbackQuery(query.id);
        if (messageId) {
          await bot.deleteMessage(chatId, messageId).catch(() => {});
        }
        await sendMainMenu(chatId, telegramUserId);
        return;
      }

      if (data === "help") {
        await bot.answerCallbackQuery(query.id);
        await bot.sendMessage(
          chatId,
          [
            "🛠 حلول المشاكل الشائعة:",
            "",
            "• تأكد أن عنوان IP والبورت صحيحين.",
            "• السيرفرات المجانية (مثل Aternos) يجب أن تكون قيد التشغيل حتى يدخلها البوت.",
            "• إذا انقطع البوت باستمرار، تأكد أن السيرفر في وضع offline-mode (cracked).",
            "• استخدم زر «فحص السيرفر» للتأكد أن السيرفر متصل بالإنترنت.",
            "• بعض استضافات مثل Aternos تمنع بوتات الـ24/7 القادمة من سيرفرات سحابية، وهذا قيد خارج عن سيطرة البوت.",
          ].join("\n"),
        );
        return;
      }

      if (data === "about") {
        await bot.answerCallbackQuery(query.id);
        await bot.sendMessage(
          chatId,
          "📦 بوت السيرفرات 24/7\nالإصدار: 1.0.0\nيبقي سيرفرات ماينكرافت الخاصة بك شغالة عن طريق الدخول كلاعب وهمي.",
        );
        return;
      }

      if (data === "add:start") {
        await bot.answerCallbackQuery(query.id);
        sessions.set(chatId, { step: "add_name", data: {} });
        await bot.sendMessage(
          chatId,
          "أرسل اسم السيرفر (تسمية مميزة له)\nمثال: سيرفري الاول",
          { reply_markup: cancelKeyboard() },
        );
        return;
      }

      const srvMatch = data.match(/^srv:(\d+):(\w+)(?::(.+))?$/);
      if (srvMatch) {
        const serverId = Number(srvMatch[1]);
        const action = srvMatch[2];
        const extra = srvMatch[3];

        const server = await getServer(serverId, telegramUserId);
        if (!server) {
          await bot.answerCallbackQuery(query.id, {
            text: "السيرفر غير موجود",
          });
          return;
        }

        if (action === "menu") {
          await bot.answerCallbackQuery(query.id);
          await sendServerMenu(chatId, server, messageId);
          return;
        }

        if (action === "start") {
          await bot.answerCallbackQuery(query.id, {
            text: "جاري تشغيل البوت...",
          });
          await startMinecraftBot(server);
          const updated = await getServer(serverId, telegramUserId);
          if (updated) await sendServerMenu(chatId, updated, messageId);
          return;
        }

        if (action === "stop") {
          await bot.answerCallbackQuery(query.id, {
            text: "جاري ايقاف البوت...",
          });
          await stopMinecraftBot(serverId);
          const updated = await getServer(serverId, telegramUserId);
          if (updated) await sendServerMenu(chatId, updated, messageId);
          return;
        }

        if (action === "info") {
          await bot.answerCallbackQuery(query.id);
          await bot.sendMessage(
            chatId,
            [
              `ℹ️ معلومات السيرفر: ${server.name}`,
              `العنوان: ${server.host}`,
              `البورت: ${server.port}`,
              `اسم اللاعب: ${server.playerName}`,
              `الحالة: ${server.isRunning ? "يعمل" : "متوقف"}`,
              `متصل فعليًا الآن: ${isServerActive(server.id) ? "نعم" : "لا"}`,
              `عدد الاتصالات: ${server.connectionCount}`,
              `عدد الانقطاعات: ${server.disconnectionCount}`,
              server.lastError ? `آخر خطأ: ${server.lastError}` : "",
            ]
              .filter(Boolean)
              .join("\n"),
          );
          return;
        }

        if (action === "check") {
          await bot.answerCallbackQuery(query.id, {
            text: "جاري فحص السيرفر...",
          });
          const result = await checkMinecraftServer(server.host, server.port);
          const text = result.online
            ? [
                "🔍 نتيجة الفحص: السيرفر متصل ✅",
                result.version ? `الإصدار: ${result.version}` : "",
                result.playersOnline !== undefined
                  ? `اللاعبون: ${result.playersOnline}/${result.playersMax}`
                  : "",
                result.motd ? `الوصف: ${result.motd}` : "",
              ]
                .filter(Boolean)
                .join("\n")
            : `🔍 نتيجة الفحص: السيرفر غير متصل ❌\n${result.error ?? ""}`;
          await bot.sendMessage(chatId, text);
          return;
        }

        if (action === "color") {
          await bot.answerCallbackQuery(query.id);
          await bot.sendMessage(chatId, "اختر لون البوت:", {
            reply_markup: {
              inline_keyboard: [
                Object.entries(COLORS).map(([key, emoji]) => ({
                  text: emoji,
                  callback_data: `srv:${serverId}:setcolor:${key}`,
                })),
              ],
            },
          });
          return;
        }

        if (action === "setcolor" && extra) {
          await db
            .update(minecraftServersTable)
            .set({ botColor: extra })
            .where(eq(minecraftServersTable.id, serverId));
          await bot.answerCallbackQuery(query.id, { text: "تم تغيير اللون" });
          const updated = await getServer(serverId, telegramUserId);
          if (updated) await sendServerMenu(chatId, updated);
          return;
        }

        if (action === "edit") {
          await bot.answerCallbackQuery(query.id);
          await bot.sendMessage(chatId, "اختر ما تريد تعديله:", {
            reply_markup: {
              inline_keyboard: [
                [
                  {
                    text: "اسم السيرفر",
                    callback_data: `srv:${serverId}:editfield:name`,
                  },
                ],
                [
                  {
                    text: "عنوان IP",
                    callback_data: `srv:${serverId}:editfield:host`,
                  },
                ],
                [
                  {
                    text: "البورت",
                    callback_data: `srv:${serverId}:editfield:port`,
                  },
                ],
                [
                  {
                    text: "اسم اللاعب",
                    callback_data: `srv:${serverId}:editfield:player`,
                  },
                ],
                [{ text: "◀️ رجوع", callback_data: `srv:${serverId}:menu` }],
              ],
            },
          });
          return;
        }

        if (action === "editfield" && extra) {
          await bot.answerCallbackQuery(query.id);
          const prompts: Record<string, string> = {
            name: "أرسل الاسم الجديد للسيرفر",
            host: "أرسل عنوان IP الجديد",
            port: "أرسل البورت الجديد",
            player: "أرسل اسم اللاعب الجديد",
          };
          const stepMap: Record<string, SessionStep> = {
            name: "edit_name",
            host: "edit_host",
            port: "edit_port",
            player: "edit_player",
          };
          sessions.set(chatId, {
            step: stepMap[extra],
            serverId,
            data: {},
          });
          await bot.sendMessage(chatId, prompts[extra] ?? "أرسل القيمة الجديدة", {
            reply_markup: cancelKeyboard(),
          });
          return;
        }

        if (action === "delete") {
          await bot.answerCallbackQuery(query.id);
          await bot.sendMessage(
            chatId,
            `هل أنت متأكد من حذف السيرفر «${server.name}»؟`,
            {
              reply_markup: {
                inline_keyboard: [
                  [
                    {
                      text: "✅ نعم، احذف",
                      callback_data: `srv:${serverId}:confirmdelete`,
                    },
                    { text: "❌ إلغاء", callback_data: `srv:${serverId}:menu` },
                  ],
                ],
              },
            },
          );
          return;
        }

        if (action === "confirmdelete") {
          await stopMinecraftBot(serverId);
          await db
            .delete(minecraftServersTable)
            .where(eq(minecraftServersTable.id, serverId));
          await bot.answerCallbackQuery(query.id, { text: "تم الحذف" });
          if (messageId) {
            await bot.deleteMessage(chatId, messageId).catch(() => {});
          }
          await sendMainMenu(chatId, telegramUserId);
          return;
        }
      }
    } catch (err) {
      logger.error(
        { err: err instanceof Error ? err.message : err },
        "Error handling Telegram callback",
      );
      await bot
        .answerCallbackQuery(query.id, { text: "حدث خطأ، حاول مجددًا" })
        .catch(() => {});
    }
  });

  bot.on("message", async (msg) => {
    if (!msg.text || msg.text.startsWith("/")) return;
    const chatId = msg.chat.id;
    const session = sessions.get(chatId);
    if (!session) return;

    const telegramUserId = String(chatId);
    const text = msg.text.trim();

    try {
      switch (session.step) {
        case "add_name": {
          session.data.name = text;
          session.step = "add_host";
          await bot.sendMessage(
            chatId,
            "أرسل عنوان IP للسيرفر\nمثال: play.example.com",
            { reply_markup: cancelKeyboard() },
          );
          break;
        }
        case "add_host": {
          session.data.host = text;
          session.step = "add_port";
          await bot.sendMessage(chatId, "أرسل بورت السيرفر\nمثال: 19132", {
            reply_markup: cancelKeyboard(),
          });
          break;
        }
        case "add_port": {
          const port = Number(text);
          if (!Number.isInteger(port) || port < 1 || port > 65535) {
            await bot.sendMessage(chatId, "البورت غير صحيح، أرسل رقم بورت صالح (1-65535)");
            break;
          }
          session.data.port = port;
          session.step = "add_player";
          await bot.sendMessage(
            chatId,
            "أرسل اسم اللاعب الذي يدخل السيرفر\nمثال: PlayerBot",
            { reply_markup: cancelKeyboard() },
          );
          break;
        }
        case "add_player": {
          session.data.playerName = text;
          const { name, host, port, playerName } = session.data;
          if (!name || !host || !port || !playerName) break;

          await db.insert(minecraftServersTable).values({
            telegramUserId,
            name,
            host,
            port,
            playerName,
          });

          sessions.delete(chatId);
          await bot.sendMessage(chatId, `✅ تم اضافة السيرفر: ${name}`);
          await sendMainMenu(chatId, telegramUserId);
          break;
        }
        case "edit_name":
        case "edit_host":
        case "edit_player": {
          if (!session.serverId) break;
          const field =
            session.step === "edit_name"
              ? "name"
              : session.step === "edit_host"
                ? "host"
                : "playerName";
          await db
            .update(minecraftServersTable)
            .set({ [field]: text })
            .where(eq(minecraftServersTable.id, session.serverId));
          sessions.delete(chatId);
          await bot.sendMessage(chatId, "✅ تم تحديث البيانات");
          const updated = await getServer(session.serverId, telegramUserId);
          if (updated) await sendServerMenu(chatId, updated);
          break;
        }
        case "edit_port": {
          if (!session.serverId) break;
          const port = Number(text);
          if (!Number.isInteger(port) || port < 1 || port > 65535) {
            await bot.sendMessage(chatId, "البورت غير صحيح، أرسل رقم بورت صالح (1-65535)");
            break;
          }
          await db
            .update(minecraftServersTable)
            .set({ port })
            .where(eq(minecraftServersTable.id, session.serverId));
          sessions.delete(chatId);
          await bot.sendMessage(chatId, "✅ تم تحديث البيانات");
          const updated = await getServer(session.serverId, telegramUserId);
          if (updated) await sendServerMenu(chatId, updated);
          break;
        }
      }
    } catch (err) {
      logger.error(
        { err: err instanceof Error ? err.message : err },
        "Error handling Telegram message",
      );
      await bot.sendMessage(chatId, "حدث خطأ، حاول مجددًا").catch(() => {});
    }
  });

  logger.info("Telegram bot started");
  return bot;
}
